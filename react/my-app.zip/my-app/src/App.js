import logo from './logo.svg';
import './App.css';
import Message from './Message';
import Badge from './components/Badge';
import Clock from './components/Clock'

function App() {
  return (
    <div className="App">
      <h2>Container Component</h2>
      <Message></Message>
      <Badge caption="Inbox"></Badge>
      <Badge caption="Sent"></Badge>
      <Clock today={new Date()}></Clock>
    </div>
  );
}

export default App;
