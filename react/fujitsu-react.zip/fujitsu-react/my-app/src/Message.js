function Message(){
    return (
        <>
            <h2>Message Component 1</h2>
            <h2>Message Component 2</h2>
        </>
    )
}
export default Message;