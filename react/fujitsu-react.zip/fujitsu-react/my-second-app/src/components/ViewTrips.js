import React, {useState, useEffect} from 'react'
import Card from './Card'

export default function ViewTrips() {

    const [trips, setTrips] = useState([]);
    const [count, setCount] = useState(10);

    // one time initialization -> component load
    useEffect(() => {
      console.log('Initialized...')
        fetch('http://localhost:8000/trips')
        .then(res=> res.json())
        .then(data => setTrips(data))
    }, [])
    

  let tripArray = trips.map(trip => <Card key={trip.id} title={trip.title} summary={trip.description}></Card>)
  console.log(tripArray);
  return (
    <div className="container mt-5">
      <h2>Trip Details {count}</h2>
      <div className="row">
        {tripArray}
      </div>
    </div>
  )
}


//   const [trips, setTrips] = useState([
//     {title: 'Hakone', summary: 'Hakone summary'},
//     {title: 'Disney', summary: 'Disney summary'},
//     {title: 'Tokyo Tower', summary: 'Tokyo Tower summary'},
//     {title: 'Ueno', summary: 'Ueno summary'},
//     {title: 'Ueno', summary: 'Ueno summary'}
//   ])  
