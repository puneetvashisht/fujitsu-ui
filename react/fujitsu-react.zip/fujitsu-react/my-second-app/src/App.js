import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css'
import ViewTrips from './components/ViewTrips';

function App() {
  return (
    <div className="App">
      <ViewTrips/>
    </div>
  );
}

export default App;
