import React from 'react'

export default function DropdownItem(props) {

    const handleItemClick = () => {
        console.log('clicked...', props.caption);
        props.whenItemClicked(props.caption)
    }

  return (
    <li><a onClick={handleItemClick} class="dropdown-item" href="#">{props.caption}</a></li>
  )
}
