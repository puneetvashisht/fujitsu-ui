import React, { useEffect, useState } from 'react'
import Card from './Card'

export default function Workout() {

    const [workouts, setworkouts] = useState([])

    useEffect(()=>{
        fetch('http://localhost:8080/api/v1/workouts')
        .then(res => res.json())
        .then( content => setworkouts(content))
    }, [])

   let listWorkouts = workouts.map((workout)=> <Card title={workout.title} summary={workout.description}></Card>)

  return (
    <div className='container row'>{listWorkouts}</div>
  )
}
