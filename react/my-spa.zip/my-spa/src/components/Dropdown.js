import React, {useState} from 'react'
import DropdownItem from './DropdownItem'

export default function Dropdown() {

    
  const [show, setShow] = useState(false) 
  const [title, setTitle] = useState() 

  const [cuisines, setCuisines] = useState(['Indian', 'Japanese', 'Continental'])

  const toggleShow = () => {
    setShow(!show)
  }

  const handleItemClickInParent = (item) => {
    console.log(item);
    setTitle(item)
    setShow(false)
  }

  let cuisineList = cuisines.map((cuisine)=> <DropdownItem caption={cuisine} whenItemClicked= {handleItemClickInParent}></DropdownItem>)

  return (
    <div class="dropdown">
    <button onClick={toggleShow} class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        {title || 'Select Cuisine'}
    </button>
    <ul class={show?'dropdown-menu show': 'dropdown-menu'}>
        {/* <DropdownItem caption = "First" whenItemClicked= {handleItemClickInParent}></DropdownItem>
        <DropdownItem caption = "Second" whenItemClicked= {handleItemClickInParent}></DropdownItem>
        <DropdownItem caption = "Third" whenItemClicked= {handleItemClickInParent}></DropdownItem> */}
        {/* <li><a class="dropdown-item" href="#">Another action</a></li>
        <li><a class="dropdown-item" href="#">Something else here</a></li> */}
        {cuisineList}
    </ul>
    </div>
  )
}
