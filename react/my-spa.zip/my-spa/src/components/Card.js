import React from 'react'
import { Link } from 'react-router-dom'


export default function Card(props) {

  const deleteTrip = async (id) => {
    const res = await fetch('http://localhost:8000/trips/' + id, {
      method: "DELETE"
    })
    if(res.status === 200){
      console.log('Trip deleted...')
      props.whenTripDeleted('Trip deleted successfully!')
    }
    
  }

  return (
    <div className="card" style={{width: '18rem'}}>
    <img src="https://picsum.photos/400" className="card-img-top" alt="..."/>
    <div className="card-body">
        <h5 className="card-title">{props.title}</h5>
        <p className="card-text">{props.summary}</p>
        <Link to={`update/${props.id}`} className="btn btn-primary">Edit</Link>
        {/* <Badge caption="Votes"></Badge> */}
        <button onClick={()=>deleteTrip(props.id)} className='btn btn-danger'> X </button>
    </div>
    </div>
  )
}
