import React from 'react'

export default function AddTrip() {
  return (
    <div>AddTrip Page</div>
  )
}
