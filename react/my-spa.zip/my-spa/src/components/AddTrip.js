import React, { useState } from 'react'

import { useParams } from "react-router-dom";

export default function AddTrip() {

  const [title, setTitle] = useState('')  
  const [description, setDescription] = useState('')  
  const [tripdate, setTripdate] = useState()  
  const [message, setMessage] = useState('')  

  const { tripid } = useParams();

 

  const handleChange = (e) => {
    setTitle(e.target.value);
    console.log(title);
  }


  const addTrip = () => {
    console.log(title, description, tripdate);
    fetch('http://localhost:8000/trips', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({title, description})
    })
    .then(res => {
        if(res.status === 201){
            setMessage('Trip added sucessfully!')
        }
    })
  }


  const updateTrip = () => {
    console.log(title, description, tripdate);
    fetch('http://localhost:8000/trips/' + tripid, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({title, description})
    })
    .then(res => {
        if(res.status === 200){
            setMessage('Trip updated sucessfully!')
        }
    })
  }

  return (
    <div className="container mt-5">
    <h2>{tripid? 'Update':'Add'} a New Trip {tripid}</h2>

    {message && <div class="alert alert-success" role="alert">
        {message}
    </div>}
    <form id="tripForm">
      <div className="form-group">
        <label forname="title">Destination (Title)</label>
        <input
          type="text"
          className="form-control"
          id="title"
          placeholder="Enter destination"
          value={title}
          onChange={handleChange}
          title="Enter the destination for your trip"
        /> 
      </div>
      <div className="form-group">
        <label forname="description">Description</label>
        <textarea
          className="form-control"
          id="description"
          rows="3"
          placeholder="Trip description"
          value={description}
          onChange={(e)=> setDescription(e.target.value)}
          title="Enter a brief description of your trip"
        ></textarea>
      </div>
      <div className="form-group">
        <label forname="date">Date</label>
        <input
          type="date"
          className="form-control"
          id="date"
          placeholder="Select date"
          value={tripdate}
          onChange={(e)=> setTripdate(e.target.value)}
          title="Click to select the date of your trip"
        />
      </div>
      {tripid?<button onClick={updateTrip} type="button" className="btn btn-primary">Update</button>:<button onClick={addTrip} type="button" className="btn btn-primary">Add</button>}
    </form>
  </div>
  )
}
