import React from 'react'
import Dropdown from './Dropdown'
import ProgressBar from 'react-bootstrap/ProgressBar';

import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import Dialog from './Dialog';

export default function About() {
  return (
    <div>
      <h2>About Us</h2>
      <ProgressBar now={10} />;
      <Dropdown></Dropdown>
      <Dialog title="abc" body='abc body'></Dialog>
    
    </div>
    // <Tabs
    //   defaultActiveKey="profile"
    //   id="uncontrolled-tab-example"
    //   className="mb-3"
    // >
    //   <Tab eventKey="home" title="Home">
    //     Tab content for Home
    //   </Tab>
    //   <Tab eventKey="profile" title="Profile">
    //     Tab content for Profile
    //   </Tab>
    //   <Tab eventKey="contact" title="Contact" disabled>
    //     Tab content for Contact
    //   </Tab>
    // </Tabs>
  )
}
