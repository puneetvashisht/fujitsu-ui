import React, {useState, useEffect} from 'react'
import Card from './Card'

export default function ViewTrips() {

    const [trips, setTrips] = useState([]);
    const [search, setSearch] = useState('');
    const [count] = useState(10);
    const [message, setMessage] = useState('') 


    const showMessage = (message, id)  => {
        let remainingTrips = trips.filter(trip => trip.id != id)
        setTrips(remainingTrips)
        setMessage(message)
    }

    // one time initialization -> component load
    useEffect(() => {
      console.log('Initialized...')
        fetch('http://localhost:8000/trips')
        .then(res=> res.json())
        .then(data => setTrips(data))
    }, [])
    

    const handleChange = (e)=> {
      setSearch(e.target.value)
      // console.log(search);
      
    }
    const handleBlur = () =>{
      const filteredTrips = trips.filter((trip) => trip.title.includes(search))
      console.log(filteredTrips);
      setTrips(filteredTrips)
    }

    const sortTrips = (order) => {
      let sortedData = [...trips]
          .sort((a, b) => {
            return order === "asc"
              ? a.title.localeCompare(b.title)
              : b.title.localeCompare(a.title);
          });

      console.log(sortedData)
      setTrips(sortedData)
    }

  let tripArray = trips.map(trip => <Card whenTripDeleted={showMessage} key={trip.id} id={trip.id} title={trip.title} summary={trip.description}></Card>)
  console.log(tripArray);
  return (
    <div className="container mt-5">
      <h2>Trip Details</h2>
      {message && <div class="alert alert-success" role="alert">
        {message}
    </div>}
      <div className='row'>
      <div class="mb-3">
        <input
          type="text"
          value = {search}
          onChange={handleChange}
          onBlur={handleBlur}
          class="form-control"
          placeholder="Search trips..."
        />
         <button
          type="button"
          class="btn btn-secondary"
          onClick={()=>sortTrips('asc')}
        >
          A-Z
        </button>
         <button
          type="button"
          class="btn btn-secondary"
          onClick={()=>sortTrips('desc')}
        >
          Z-A
        </button>
      </div>
      </div>
      <div className="row">

        {tripArray}
      </div>
    </div>
  )
}


//   const [trips, setTrips] = useState([
//     {title: 'Hakone', summary: 'Hakone summary'},
//     {title: 'Disney', summary: 'Disney summary'},
//     {title: 'Tokyo Tower', summary: 'Tokyo Tower summary'},
//     {title: 'Ueno', summary: 'Ueno summary'},
//     {title: 'Ueno', summary: 'Ueno summary'}
//   ])  
