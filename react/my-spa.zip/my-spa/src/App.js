import logo from './logo.svg';
import './App.css';
import ViewTrips from './components/ViewTrips';
import AddTrip from './components/AddTrip';
import { Route, Routes, Link, Outlet } from 'react-router-dom';
import About from './components/About';

function App() {
  return (
    <>

      <ul className="nav">
        <li className="nav-item">
          <Link className="nav-link active" aria-current="page" to="/">View Trips</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/add">Add Trip</Link>
        </li>
        <li className="nav-item">
          {/* <a className="nav-link" href="/add">Link</a>
           */}
           <Link className="nav-link" to="/about">About Us</Link>
        </li>
        <li className="nav-item">
          <a className="nav-link disabled" aria-disabled="true">Disabled</a>
        </li>
      </ul>

      <div id="view-area">
        <Outlet></Outlet>
      </div>
        <Routes>
          <Route path="add" element={<AddTrip />} />
          <Route path="update/:tripid" element={<AddTrip />} />
          <Route path="about" element={<About />} />
          <Route path="*" element={<NoMatch />} />
          <Route path="/" element={<ViewTrips />}>
        </Route>
      </Routes>
    </>
    
  );
}

export default App;


function NoMatch() {
  return (
    <div>
      <h2>Nothing to see here!</h2>
      <p>
        <Link to="/">Go to the home page</Link>
      </p>
    </div>
  );
}
