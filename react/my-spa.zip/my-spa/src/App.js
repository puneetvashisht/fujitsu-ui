import logo from './logo.svg';
import './App.css';
import ViewTrips from './components/ViewTrips';
import AddTrip from './components/AddTrip';
import { Route, Routes, Link, Outlet } from 'react-router-dom';
import About from './components/About';

function App() {
  return (
    <>

      <ul class="nav">
        <li class="nav-item">
          <Link class="nav-link active" aria-current="page" to="/">View Trips</Link>
        </li>
        <li class="nav-item">
          <Link class="nav-link" to="/add">Add Trip</Link>
        </li>
        <li class="nav-item">
          {/* <a class="nav-link" href="/add">Link</a>
           */}
           <Link class="nav-link" to="/about">About Us</Link>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true">Disabled</a>
        </li>
      </ul>

      <div id="view-area">
        <Outlet></Outlet>
      </div>
        <Routes>
          <Route path="add" element={<AddTrip />} />
          <Route path="about" element={<About />} />
          <Route path="*" element={<NoMatch />} />
          <Route path="/" element={<ViewTrips />}>
        </Route>
      </Routes>
    </>
    
  );
}

export default App;


function NoMatch() {
  return (
    <div>
      <h2>Nothing to see here!</h2>
      <p>
        <Link to="/">Go to the home page</Link>
      </p>
    </div>
  );
}
